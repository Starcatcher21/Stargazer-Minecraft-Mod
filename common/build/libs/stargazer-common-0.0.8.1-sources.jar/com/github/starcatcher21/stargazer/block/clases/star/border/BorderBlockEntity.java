package com.github.starcatcher21.stargazer.block.clases.star.border;

import com.github.starcatcher21.stargazer.block.BlockTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class BorderBlockEntity extends BlockEntity {
    public BorderBlockEntity(BlockPos pos, BlockState state) {
        super(BlockTypes.BORDER_BLOCK.get(), pos, state);
    }
}
