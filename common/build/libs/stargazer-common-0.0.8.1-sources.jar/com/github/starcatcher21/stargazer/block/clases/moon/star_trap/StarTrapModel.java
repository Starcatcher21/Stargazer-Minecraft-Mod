package com.github.starcatcher21.stargazer.block.clases.moon.star_trap;

import com.github.starcatcher21.stargazer.Stargazer;
import net.minecraft.resources.Identifier;
import com.geckolib.model.GeoModel;
import com.geckolib.renderer.base.GeoRenderState;

public class StarTrapModel extends GeoModel<StarTrapEntity> {
    private final Identifier model = Identifier.fromNamespaceAndPath(Stargazer.MOD_ID, "block/star_trap");
    private final Identifier animations = Identifier.fromNamespaceAndPath(Stargazer.MOD_ID, "block/star_trap");
    private final Identifier texture = Identifier.fromNamespaceAndPath(Stargazer.MOD_ID, "textures/block/star_trap.png");

    @Override
    public Identifier getModelResource(GeoRenderState renderState) {
        return model;
    }

    @Override
    public Identifier getTextureResource(GeoRenderState renderState) {
        return texture;
    }

    @Override
    public Identifier getAnimationResource(StarTrapEntity animatable) {
        return animations;
    }
}

