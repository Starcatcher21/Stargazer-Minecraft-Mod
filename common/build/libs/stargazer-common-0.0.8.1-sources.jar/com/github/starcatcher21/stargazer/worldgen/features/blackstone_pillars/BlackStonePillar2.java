package com.github.starcatcher21.stargazer.worldgen.features.blackstone_pillars;

import com.github.starcatcher21.starlib.worldgen.features.trees.Tree;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class BlackStonePillar2 {
    public static void init(Tree tree) {
        tree.addReplacableBlock(Blocks.AIR);
        for (BlockState state : tree.leave) {
            tree.addReplacableBlock(state.getBlock());
        }
        // logs
        for (int h = 0; h <= 7; h++) {
            for (int x = 0; x < 2; x++) {
                for (int z = 0; z < 2; z++) {
                    tree.addLogPos(x, h, z);
                }
            }
        }
        tree.addLogPos(0, 8,0);
    }
}
