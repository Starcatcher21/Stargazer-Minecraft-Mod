package com.github.starcatcher21.stargazer.fabric.datagen;

import com.github.starcatcher21.stargazer.Stargazer;
import com.github.starcatcher21.stargazer.block.ModFluids;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagsProvider;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.material.Fluid;

import java.util.concurrent.CompletableFuture;

public class FluidTagProvider extends FabricTagsProvider.FluidTagsProvider {
    public FluidTagProvider(FabricPackOutput output, CompletableFuture<HolderLookup.Provider> registriesFuture) {
        super(output, registriesFuture);
    }

    public static final TagKey<Fluid> DREAM = of("dream");

    private static TagKey<Fluid> of(String id) {
        return TagKey.create(Registries.FLUID, Identifier.fromNamespaceAndPath(Stargazer.MOD_ID, id));
    }

    @Override
    protected void addTags(HolderLookup.Provider wrapperLookup) {
        builder(DREAM)
                .add(ModFluids.DREAM.getFlowing().builtInRegistryHolder().key())
                .add(ModFluids.DREAM.builtInRegistryHolder().key());
    }
}
